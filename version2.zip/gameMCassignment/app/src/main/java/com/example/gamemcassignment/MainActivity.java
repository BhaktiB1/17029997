package com.example.gamemcassignment;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;        //for View
import android.widget.ImageView; // for linking the ImageView object
import android.view.MotionEvent; //for touch and drag event
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView apple1 = (ImageView) findViewById(R.id.apple1);
        apple1.setOnTouchListener(handleTouch);
        ImageView apple2 = (ImageView) findViewById(R.id.apple2);
        apple2.setOnTouchListener(handleTouch);
        ImageView apple3 = (ImageView) findViewById(R.id.apple3);
        apple3.setOnTouchListener(handleTouch);
        ImageView apple4 = (ImageView) findViewById(R.id.apple4);
        apple4.setOnTouchListener(handleTouch);
        ImageView apple5 = (ImageView) findViewById(R.id.apple5);
        apple5.setOnTouchListener(handleTouch);
        ImageView apple6 = (ImageView) findViewById(R.id.apple6);
        apple6.setOnTouchListener(handleTouch);
        ImageView apple7 = (ImageView) findViewById(R.id.apple7);
        apple7.setOnTouchListener(handleTouch);
        ImageView apple8 = (ImageView) findViewById(R.id.apple8);
        apple8.setOnTouchListener(handleTouch);
        ImageView apple9 = (ImageView) findViewById(R.id.apple9);
        apple9.setOnTouchListener(handleTouch);
        // need the variables public
        final Random randomNo = new Random();
        final TextView number1 = (TextView) findViewById(R.id.r1);
        number1.setText(String.valueOf(randomNo.nextInt(6)));
        final TextView number2 = (TextView) findViewById(R.id.r2);
        number2.setText(String.valueOf(randomNo.nextInt(5)));
    }

    private View.OnTouchListener handleTouch = new View.OnTouchListener() {
        float dX, dY;
        @Override
        public boolean onTouch(View view, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dX = view.getX() - event.getRawX();
                    dY = view.getY() - event.getRawY();
                    break;
                case MotionEvent.ACTION_MOVE:
                    view.animate()
                            .x(event.getRawX() + dX)
                            .y(event.getRawY() + dY)
                            .setDuration(0)
                            .start();
                    break; default:
                    return false;
            }
            return true;
        }
    };

    int result;
    TextView myTextView;

    public void image0click (View v){
        TextView result = (TextView)findViewById(R.id.result);
        result.setText("0");
    }
    public void image1click (View v){
        TextView result = (TextView)findViewById(R.id.result);
        result.setText("1");
    }
    public void image2click (View v){
        TextView result = (TextView)findViewById(R.id.result);
        result.setText("2");
    }
    public void image3click (View v){
        TextView result = (TextView)findViewById(R.id.result);
        result.setText("3");
    }
    public void image4click (View v){
        TextView result = (TextView)findViewById(R.id.result);
        result.setText("4");
    }
    public void image5click (View v){
        TextView result = (TextView)findViewById(R.id.result);
        result.setText("5");
    }
    public void image6click (View v){
        TextView result = (TextView)findViewById(R.id.result);
        result.setText("6");
    }
    public void image7click (View v){
        TextView result = (TextView)findViewById(R.id.result);
        result.setText("7");
    }
    public void image8click (View v){
        TextView result = (TextView)findViewById(R.id.result);
        result.setText("8");
    }
    public void image9click (View v){
        TextView result = (TextView)findViewById(R.id.result);
        result.setText("9");
    }


}