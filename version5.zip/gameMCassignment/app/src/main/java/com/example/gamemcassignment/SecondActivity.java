package com.example.gamemcassignment;

import android.media.MediaPlayer;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.animation.Animation;

public class SecondActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);

        ImageView image = (ImageView)findViewById(R.id.play);
        Animation animation1 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade);
        image.startAnimation(animation1);

        ImageView bgimage = (ImageView)findViewById(R.id.bg);
        Animation animation2 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.blink);
        bgimage.startAnimation(animation2);

        String num1 = getIntent().getStringExtra("num1");
        TextView n1 = (TextView) findViewById(R.id.r1);
        n1.setText(num1);

        String num2 = getIntent().getStringExtra("num2");
        TextView n2 = (TextView) findViewById(R.id.r2);
        n2.setText(num2);

        String value = getIntent().getStringExtra("answer");
        TextView result = (TextView) findViewById(R.id.answer);
        result.setText(value);

        int number1 = Integer.parseInt(n1.getText().toString());
        int number2 = Integer.parseInt(n2.getText().toString());
        int val = Integer.parseInt(result.getText().toString());

        String mString;
        if ((number1 + number2) == val) {
            final MediaPlayer mp = MediaPlayer.create(this, R.raw.soundeffect);
            mp.start();
            TextView r = (TextView) findViewById(R.id.result);
            mString = "Well done!";
            r.setText(mString);
        } else {
            TextView r = (TextView) findViewById(R.id.result);
            mString = "Try again";
            r.setText(mString);
        }
    }

    public void playAgain(View v){
        Intent intent = new Intent(v.getContext(),MainActivity.class);
        startActivity(intent);
    }

}