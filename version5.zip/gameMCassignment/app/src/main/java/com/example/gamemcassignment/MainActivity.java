package com.example.gamemcassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;        //for View
import android.widget.ImageView; // for linking the ImageView object
import android.view.MotionEvent; //for touch and drag event
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView apple1 = (ImageView) findViewById(R.id.apple1);
        apple1.setOnTouchListener(handleTouch);
        ImageView apple2 = (ImageView) findViewById(R.id.apple2);
        apple2.setOnTouchListener(handleTouch);
        ImageView apple3 = (ImageView) findViewById(R.id.apple3);
        apple3.setOnTouchListener(handleTouch);
        ImageView apple4 = (ImageView) findViewById(R.id.apple4);
        apple4.setOnTouchListener(handleTouch);
        ImageView apple5 = (ImageView) findViewById(R.id.apple5);
        apple5.setOnTouchListener(handleTouch);
        ImageView apple6 = (ImageView) findViewById(R.id.apple6);
        apple6.setOnTouchListener(handleTouch);
        ImageView apple7 = (ImageView) findViewById(R.id.apple7);
        apple7.setOnTouchListener(handleTouch);
        ImageView apple8 = (ImageView) findViewById(R.id.apple8);
        apple8.setOnTouchListener(handleTouch);
        ImageView apple9 = (ImageView) findViewById(R.id.apple9);
        apple9.setOnTouchListener(handleTouch);
        final Random randomNo = new Random();
        final TextView number1 = (TextView) findViewById(R.id.r1);
        number1.setText(String.valueOf(randomNo.nextInt(6)));
        final TextView number2 = (TextView) findViewById(R.id.r2);
        number2.setText(String.valueOf(randomNo.nextInt(5)));
    }

    private View.OnTouchListener handleTouch = new View.OnTouchListener() {
        float dX, dY;
        @SuppressLint("ClickableViewAccessibility")
        @Override
        public boolean onTouch(View view, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dX = view.getX() - event.getRawX();
                    dY = view.getY() - event.getRawY();
                    break;
                case MotionEvent.ACTION_MOVE:
                    view.animate()
                            .x(event.getRawX() + dX)
                            .y(event.getRawY() + dY)
                            .setDuration(0)
                            .start();
                    break;
                default:
                    return false;
            }
            return true;
        }
    };

    public void image0click (View v){
        TextView result = (TextView)findViewById(R.id.answer);
        result.setText("0");
//        startActivity(new Intent(MainActivity.this, SecondActivity.class));
        Intent myIntent = new Intent(v.getContext(),SecondActivity.class);
        String r1 = ((TextView)findViewById(R.id.r1)).getText().toString();
        myIntent.putExtra("num1", r1);
        String r2 = ((TextView)findViewById(R.id.r2)).getText().toString();
        myIntent.putExtra("num2", r2);
        @SuppressLint("CutPasteId") String value = ((TextView)findViewById(R.id.answer)).getText().toString();
        myIntent.putExtra("answer", value);
        startActivity(myIntent);
//        View bgView;
//        bgView = (View) findViewById(R.id.view);
//        bgView.setVisibility(View.VISIBLE);
    }
    public void image1click (View v){
        TextView result = (TextView)findViewById(R.id.answer);
        result.setText("1");
        Intent myIntent = new Intent(v.getContext(),SecondActivity.class);
        String r1 = ((TextView)findViewById(R.id.r1)).getText().toString();
        myIntent.putExtra("num1", r1);
        String r2 = ((TextView)findViewById(R.id.r2)).getText().toString();
        myIntent.putExtra("num2", r2);
        @SuppressLint("CutPasteId") String value = ((TextView)findViewById(R.id.answer)).getText().toString();
        myIntent.putExtra("answer", value);
        startActivity(myIntent);
    }
    public void image2click (View v){
        TextView result = (TextView)findViewById(R.id.answer);
        result.setText("2");
        Intent myIntent = new Intent(v.getContext(),SecondActivity.class);
        String r1 = ((TextView)findViewById(R.id.r1)).getText().toString();
        myIntent.putExtra("num1", r1);
        String r2 = ((TextView)findViewById(R.id.r2)).getText().toString();
        myIntent.putExtra("num2", r2);
        @SuppressLint("CutPasteId") String value = ((TextView)findViewById(R.id.answer)).getText().toString();
        myIntent.putExtra("answer", value);
        startActivity(myIntent);
    }
    public void image3click (View v){
        TextView result = (TextView)findViewById(R.id.answer);
        result.setText("3");
        Intent myIntent = new Intent(v.getContext(),SecondActivity.class);
        String r1 = ((TextView)findViewById(R.id.r1)).getText().toString();
        myIntent.putExtra("num1", r1);
        String r2 = ((TextView)findViewById(R.id.r2)).getText().toString();
        myIntent.putExtra("num2", r2);
        @SuppressLint("CutPasteId") String value = ((TextView)findViewById(R.id.answer)).getText().toString();
        myIntent.putExtra("answer", value);
        startActivity(myIntent);
    }
    public void image4click (View v){
        TextView result = (TextView)findViewById(R.id.answer);
        result.setText("4");
        Intent myIntent = new Intent(v.getContext(),SecondActivity.class);
        String r1 = ((TextView)findViewById(R.id.r1)).getText().toString();
        myIntent.putExtra("num1", r1);
        String r2 = ((TextView)findViewById(R.id.r2)).getText().toString();
        myIntent.putExtra("num2", r2);
        @SuppressLint("CutPasteId") String value = ((TextView)findViewById(R.id.answer)).getText().toString();
        myIntent.putExtra("answer", value);
        startActivity(myIntent);
    }
    public void image5click (View v){
        TextView result = (TextView)findViewById(R.id.answer);
        result.setText("5");
        Intent myIntent = new Intent(v.getContext(),SecondActivity.class);
        String r1 = ((TextView)findViewById(R.id.r1)).getText().toString();
        myIntent.putExtra("num1", r1);
        String r2 = ((TextView)findViewById(R.id.r2)).getText().toString();
        myIntent.putExtra("num2", r2);
        @SuppressLint("CutPasteId") String value = ((TextView)findViewById(R.id.answer)).getText().toString();
        myIntent.putExtra("answer", value);
        startActivity(myIntent);
    }
    public void image6click (View v){
        TextView result = (TextView)findViewById(R.id.answer);
        result.setText("6");
        Intent myIntent = new Intent(v.getContext(),SecondActivity.class);
        String r1 = ((TextView)findViewById(R.id.r1)).getText().toString();
        myIntent.putExtra("num1", r1);
        String r2 = ((TextView)findViewById(R.id.r2)).getText().toString();
        myIntent.putExtra("num2", r2);
        @SuppressLint("CutPasteId") String value = ((TextView)findViewById(R.id.answer)).getText().toString();
        myIntent.putExtra("answer", value);
        startActivity(myIntent);
    }
    public void image7click (View v){
        TextView result = (TextView)findViewById(R.id.answer);
        result.setText("7");
        Intent myIntent = new Intent(v.getContext(),SecondActivity.class);
        String r1 = ((TextView)findViewById(R.id.r1)).getText().toString();
        myIntent.putExtra("num1", r1);
        String r2 = ((TextView)findViewById(R.id.r2)).getText().toString();
        myIntent.putExtra("num2", r2);
        @SuppressLint("CutPasteId") String value = ((TextView)findViewById(R.id.answer)).getText().toString();
        myIntent.putExtra("answer", value);
        startActivity(myIntent);
    }
    public void image8click (View v){
        TextView result = (TextView)findViewById(R.id.answer);
        result.setText("8");
        Intent myIntent = new Intent(v.getContext(),SecondActivity.class);
        String r1 = ((TextView)findViewById(R.id.r1)).getText().toString();
        myIntent.putExtra("num1", r1);
        String r2 = ((TextView)findViewById(R.id.r2)).getText().toString();
        myIntent.putExtra("num2", r2);
        @SuppressLint("CutPasteId") String value = ((TextView)findViewById(R.id.answer)).getText().toString();
        myIntent.putExtra("answer", value);
        startActivity(myIntent);
    }
    public void image9click (View v){
        TextView result = (TextView)findViewById(R.id.answer);
        result.setText("9");
        Intent myIntent = new Intent(v.getContext(),SecondActivity.class);
        String r1 = ((TextView)findViewById(R.id.r1)).getText().toString();
        myIntent.putExtra("num1", r1);
        String r2 = ((TextView)findViewById(R.id.r2)).getText().toString();
        myIntent.putExtra("num2", r2);
        @SuppressLint("CutPasteId") String value = ((TextView)findViewById(R.id.answer)).getText().toString();
        myIntent.putExtra("answer", value);
        startActivity(myIntent);
    }


//    public void checkAnswer(View v) {
//        TextView n1 = (TextView) findViewById(R.id.r1);
//        int num1 = Integer.parseInt(n1.getText().toString());
//        TextView n2 = (TextView) findViewById(R.id.r2);
//        int num2 = Integer.parseInt(n2.getText().toString());
//        TextView ans = (TextView) findViewById(R.id.answer);
//        int answer = Integer.parseInt(ans.getText().toString());
//        String mString;
//        if (num1 + num2 == answer) {
//            TextView r = (TextView) findViewById(R.id.result);
//            mString = "Correct";
//            r.setText(mString);
//        } else {
//            TextView r = (TextView) findViewById(R.id.result);
//            mString = "Incorrect";
//            r.setText(mString);
//        }
//    }

}