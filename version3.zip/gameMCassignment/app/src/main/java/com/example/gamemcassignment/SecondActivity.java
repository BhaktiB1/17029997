package com.example.gamemcassignment;

public class SecondActivity {
}
